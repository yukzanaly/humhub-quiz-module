<div class="container-fluid">
    <div class="panel panel-default">
        <div class="panel-heading"><strong>Quiz</strong> <?= Yii::t('QuizModule.base', 'configuration') ?>
        </div>
        <div class="panel-body">
            <p><?= Yii::t('QuizModule.base', 'Welcome to the admin only area.') ?></p>
            <p>This module will be used to creat exam or test where students get their scores from</p>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="panel panel-default">
        <div class="panel-heading"><strong>Section</strong> Two</div>
        <div class="panel-body">
        <p>Here will be where the quiz will be</p>
        <div class="list-group">
        <a href="#" class="list-group-item list-group-item-action" aria-current="true">Quiz 1 - Some Text</a>
        <a href="#" class="list-group-item list-group-item-action">Quiz 2 - Some Text</a>
        <a href="#" class="list-group-item list-group-item-action">Quiz 3 - Some Text</a>
        <p>When a quiz is clicked, a modul will pop up to edit it.</p>
        </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="panel panel-default">
        <div class="panel-heading"><strong>Section</strong> Three</div>
        <div class="panel-body">
        <p>Here will show log of every quiz taken.</p>
    </div>
</div>

