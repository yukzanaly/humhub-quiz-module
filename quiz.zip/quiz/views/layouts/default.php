<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                    <?= $content ?>
            </div>
        </div>
    </div>
</div>